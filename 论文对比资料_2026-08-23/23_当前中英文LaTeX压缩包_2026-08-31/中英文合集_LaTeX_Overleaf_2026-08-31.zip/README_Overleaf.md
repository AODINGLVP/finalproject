# Overleaf editable package

This package contains two LaTeX versions of the dissertation.

- Chinese version: `zh/main.tex`
- English version: `en/main.tex`

Recommended Overleaf settings:

1. Upload this ZIP to Overleaf as a new project.
2. Set the compiler to XeLaTeX.
3. For the Chinese paper, set the main document to `zh/main.tex`.
4. For the English paper, set the main document to `en/main.tex`.

The Chinese source uses the Fandol CJK font set so that it can compile on Overleaf without Windows-only fonts.
